# Crypto-razer - Porject by Straw Hats(Siddharth,Mehul,Shubham)
A dapp made on Ethereum Network to support different Organizations through crypto 

To test the Smart Contract go the Remix IDE and try it there .

Things to keep in mind : 
You must have a Metamask Wallet and some test ethers in one of the Testnet.
Don't use Javascript VM as Environment ,select Injected Web3 in remix IDE.
